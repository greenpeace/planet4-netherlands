<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Outputs schema.org NewsArticle JSON-LD on every post. Google News /
 * Discovery use this to confirm a page is a genuine news article and to
 * attribute it to the right publisher — required even after the site
 * itself is verified.
 */
class GPC_Structured_Data {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_head', array( $this, 'output_json_ld' ) );
	}

	public function output_json_ld() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}

		$post              = get_queried_object();
		$publication_name  = get_option( GPC_News_Sitemap::OPTION_NAME, get_bloginfo( 'name' ) );
		$logo              = get_site_icon_url();
		$thumbnail_id      = get_post_thumbnail_id( $post );
		$image_url         = $thumbnail_id ? wp_get_attachment_image_url( $thumbnail_id, 'full' ) : null;
		$author            = get_the_author_meta( 'display_name', $post->post_author );

		$data = array(
			'@context'         => 'https://schema.org',
			'@type'            => 'NewsArticle',
			'headline'         => html_entity_decode( get_the_title( $post ) ),
			'datePublished'    => get_the_date( 'c', $post ),
			'dateModified'     => get_the_modified_date( 'c', $post ),
			'mainEntityOfPage' => get_permalink( $post ),
			'author'           => array(
				array(
					'@type' => 'Person',
					'name'  => $author ? $author : $publication_name,
					'url'   => get_author_posts_url( $post->post_author ),
				),
			),
			'publisher'        => array(
				'@type' => 'Organization',
				'name'  => $publication_name,
				'logo'  => array(
					'@type' => 'ImageObject',
					'url'   => $logo ? $logo : '',
				),
			),
		);

		if ( $image_url ) {
			$data['image'] = array( $image_url );
		}

		echo "\n" . '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>' . "\n";
	}
}
