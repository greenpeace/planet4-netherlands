<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates a Google News sitemap scoped ONLY to this subdirectory site
 * (greenpeace.org/israel), as required by Publisher Center / Google News.
 * A sitemap pulled from a shared/global Greenpeace sitemap would mix in
 * articles from other country sites and get rejected; this one only ever
 * contains posts published on this WordPress install.
 */
class GPC_News_Sitemap {

	const QUERY_VAR    = 'gpc_news_sitemap';
	const OPTION_NAME  = 'gpc_publication_name';
	const OPTION_LANG  = 'gpc_publication_language';
	const MAX_AGE_HOURS = 48; // Google News sitemap spec: only include articles published in the last 2 days.

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'add_rewrite_rule' ) );
		add_filter( 'query_vars', array( $this, 'add_query_var' ) );
		add_action( 'template_redirect', array( $this, 'maybe_render_sitemap' ) );
	}

	public static function on_activation() {
		// Rules are added on 'init' above; flushing here makes them live immediately on activation.
		flush_rewrite_rules();
	}

	public static function on_deactivation() {
		flush_rewrite_rules();
	}

	public function add_rewrite_rule() {
		add_rewrite_rule( '^news-sitemap\.xml$', 'index.php?' . self::QUERY_VAR . '=1', 'top' );
	}

	public function add_query_var( $vars ) {
		$vars[] = self::QUERY_VAR;
		return $vars;
	}

	public function maybe_render_sitemap() {
		if ( '1' !== get_query_var( self::QUERY_VAR ) ) {
			return;
		}

		$publication_name = get_option( self::OPTION_NAME, get_bloginfo( 'name' ) );
		$language          = get_option( self::OPTION_LANG, 'he' );

		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 1000,
				'date_query'     => array(
					array(
						'after' => self::MAX_AGE_HOURS . ' hours ago',
					),
				),
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		header( 'Content-Type: application/xml; charset=utf-8' );
		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">' . "\n";

		foreach ( $posts as $post ) {
			$pub_date = get_the_date( 'Y-m-d\TH:i:sP', $post );
			printf(
				"\t<url>\n\t\t<loc>%s</loc>\n\t\t<news:news>\n\t\t\t<news:publication>\n\t\t\t\t<news:name>%s</news:name>\n\t\t\t\t<news:language>%s</news:language>\n\t\t\t</news:publication>\n\t\t\t<news:publication_date>%s</news:publication_date>\n\t\t\t<news:title>%s</news:title>\n\t\t</news:news>\n\t</url>\n",
				esc_url( get_permalink( $post ) ),
				esc_html( $publication_name ),
				esc_html( $language ),
				esc_html( $pub_date ),
				esc_html( html_entity_decode( get_the_title( $post ) ) )
			);
		}

		echo '</urlset>';
		exit;
	}

	public static function sitemap_url() {
		return home_url( '/news-sitemap.xml' );
	}
}
