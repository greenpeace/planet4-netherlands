<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles Google site-verification for a subdirectory site.
 *
 * Domain-level verification (DNS TXT, root HTML file) is impossible here
 * because we don't control the root of greenpeace.org. The two methods
 * below both verify ownership of just the /israel URL prefix, which is
 * exactly what WordPress controls — so both work without root access.
 */
class GPC_Verification {

	const OPTION_META_TAGS = 'gpc_verification_meta_tags';
	const OPTION_HTML_FILES = 'gpc_verification_html_files';

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_head', array( $this, 'output_meta_tags' ), 1 );
		add_action( 'template_redirect', array( $this, 'maybe_serve_html_file' ), 0 );
	}

	/**
	 * Method 1: meta tag verification (Search Console "URL prefix" property,
	 * "HTML tag" option). Stored as a list so several Google accounts/products
	 * (Search Console + Publisher Center) can verify independently.
	 */
	public function output_meta_tags() {
		$tags = get_option( self::OPTION_META_TAGS, array() );
		foreach ( (array) $tags as $content ) {
			$content = trim( $content );
			if ( '' === $content ) {
				continue;
			}
			printf( '<meta name="google-site-verification" content="%s" />' . "\n", esc_attr( $content ) );
		}
	}

	/**
	 * Method 2: HTML file verification. Google gives you a file such as
	 * google1234567890abcdef.html that normally has to be uploaded to the
	 * web root. Since our web root belongs to someone else, we instead let
	 * WordPress answer that exact request itself, scoped to our own path
	 * (e.g. www.greenpeace.org/israel/google1234567890abcdef.html).
	 */
	public function maybe_serve_html_file( $skip_wp = false ) {
		$files = get_option( self::OPTION_HTML_FILES, array() );
		if ( empty( $files ) ) {
			return;
		}

		$request_path = wp_parse_url( add_query_arg( array() ), PHP_URL_PATH );
		$home_path    = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$relative     = '/' . ltrim( substr( (string) $request_path, strlen( (string) $home_path ) ), '/' );

		foreach ( (array) $files as $filename => $body ) {
			if ( '/' . ltrim( $filename, '/' ) === $relative ) {
				status_header( 200 );
				header( 'Content-Type: text/html; charset=utf-8' );
				echo wp_kses( $body, array() ); // phpcs:ignore -- verification files are plain Google-issued markup.
				exit;
			}
		}
	}

	public static function get_meta_tags() {
		return get_option( self::OPTION_META_TAGS, array() );
	}

	public static function save_meta_tags( array $tags ) {
		update_option( self::OPTION_META_TAGS, array_values( array_filter( array_map( 'sanitize_text_field', $tags ) ) ) );
	}

	public static function get_html_files() {
		return get_option( self::OPTION_HTML_FILES, array() );
	}

	public static function save_html_file( $filename, $body ) {
		$filename = sanitize_file_name( $filename );
		if ( '' === $filename || '' === trim( $body ) ) {
			return false;
		}
		$files             = self::get_html_files();
		$files[ $filename ] = wp_kses( $body, array() );
		update_option( self::OPTION_HTML_FILES, $files );
		return true;
	}

	public static function delete_html_file( $filename ) {
		$files = self::get_html_files();
		unset( $files[ sanitize_file_name( $filename ) ] );
		update_option( self::OPTION_HTML_FILES, $files );
	}
}
