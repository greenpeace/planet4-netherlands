<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GPC_Admin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_post_gpc_save_general', array( $this, 'handle_save_general' ) );
		add_action( 'admin_post_gpc_add_meta_tag', array( $this, 'handle_add_meta_tag' ) );
		add_action( 'admin_post_gpc_remove_meta_tag', array( $this, 'handle_remove_meta_tag' ) );
		add_action( 'admin_post_gpc_add_html_file', array( $this, 'handle_add_html_file' ) );
		add_action( 'admin_post_gpc_remove_html_file', array( $this, 'handle_remove_html_file' ) );
	}

	public function add_settings_page() {
		add_options_page(
			__( 'Publisher Center', 'gpc' ),
			__( 'Publisher Center', 'gpc' ),
			'manage_options',
			'gpc-settings',
			array( $this, 'render_settings_page' )
		);
	}

	private function check( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'gpc' ) );
		}
		check_admin_referer( $action );
	}

	public function handle_save_general() {
		$this->check( 'gpc_save_general' );
		update_option( GPC_News_Sitemap::OPTION_NAME, sanitize_text_field( $_POST['publication_name'] ?? '' ) );
		update_option( GPC_News_Sitemap::OPTION_LANG, sanitize_text_field( $_POST['publication_language'] ?? 'he' ) );
		wp_safe_redirect( add_query_arg( 'updated', '1', wp_get_referer() ) );
		exit;
	}

	public function handle_add_meta_tag() {
		$this->check( 'gpc_add_meta_tag' );
		$tags   = GPC_Verification::get_meta_tags();
		$tags[] = sanitize_text_field( $_POST['meta_content'] ?? '' );
		GPC_Verification::save_meta_tags( $tags );
		wp_safe_redirect( add_query_arg( 'updated', '1', wp_get_referer() ) );
		exit;
	}

	public function handle_remove_meta_tag() {
		$this->check( 'gpc_remove_meta_tag' );
		$tags = GPC_Verification::get_meta_tags();
		$idx  = (int) ( $_POST['index'] ?? -1 );
		if ( isset( $tags[ $idx ] ) ) {
			unset( $tags[ $idx ] );
		}
		GPC_Verification::save_meta_tags( $tags );
		wp_safe_redirect( add_query_arg( 'updated', '1', wp_get_referer() ) );
		exit;
	}

	public function handle_add_html_file() {
		$this->check( 'gpc_add_html_file' );
		GPC_Verification::save_html_file(
			sanitize_text_field( $_POST['filename'] ?? '' ),
			wp_unslash( $_POST['file_body'] ?? '' )
		);
		wp_safe_redirect( add_query_arg( 'updated', '1', wp_get_referer() ) );
		exit;
	}

	public function handle_remove_html_file() {
		$this->check( 'gpc_remove_html_file' );
		GPC_Verification::delete_html_file( sanitize_text_field( $_POST['filename'] ?? '' ) );
		wp_safe_redirect( add_query_arg( 'updated', '1', wp_get_referer() ) );
		exit;
	}

	public function render_settings_page() {
		$meta_tags  = GPC_Verification::get_meta_tags();
		$html_files = GPC_Verification::get_html_files();
		$sitemap_url = GPC_News_Sitemap::sitemap_url();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Google Publisher Center Connector', 'gpc' ); ?></h1>
			<p>
				<?php esc_html_e( 'This site lives in a subdirectory of a domain you do not control the root of. The tools below verify and feed only this path, which is exactly what Search Console / Publisher Center needs.', 'gpc' ); ?>
			</p>

			<?php if ( isset( $_GET['updated'] ) ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Saved.', 'gpc' ); ?></p></div>
			<?php endif; ?>

			<h2><?php esc_html_e( '1. Publication details', 'gpc' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'gpc_save_general' ); ?>
				<input type="hidden" name="action" value="gpc_save_general" />
				<table class="form-table">
					<tr>
						<th><label for="publication_name"><?php esc_html_e( 'Publication name', 'gpc' ); ?></label></th>
						<td><input type="text" id="publication_name" name="publication_name" class="regular-text" value="<?php echo esc_attr( get_option( GPC_News_Sitemap::OPTION_NAME, get_bloginfo( 'name' ) ) ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="publication_language"><?php esc_html_e( 'Language code', 'gpc' ); ?></label></th>
						<td><input type="text" id="publication_language" name="publication_language" class="small-text" value="<?php echo esc_attr( get_option( GPC_News_Sitemap::OPTION_LANG, 'he' ) ); ?>" /></td>
					</tr>
				</table>
				<?php submit_button( __( 'Save', 'gpc' ) ); ?>
			</form>

			<hr />

			<h2><?php esc_html_e( '2. Site verification', 'gpc' ); ?></h2>
			<p><?php esc_html_e( 'Use the "URL prefix" property type in Search Console / Publisher Center (not "Domain"), pointed at this exact path. Domain-type verification requires DNS access to the root, which you do not have — URL-prefix verification only requires this WordPress install to answer, which both options below do.', 'gpc' ); ?></p>

			<h3><?php esc_html_e( 'Option A: HTML tag', 'gpc' ); ?></h3>
			<p><?php esc_html_e( 'Paste the content="..." value Google gives you for the HTML tag method. It will be added to the <head> of every page on this site.', 'gpc' ); ?></p>
			<table class="widefat" style="max-width:700px">
				<tbody>
				<?php foreach ( $meta_tags as $i => $tag ) : ?>
					<tr>
						<td><code><?php echo esc_html( $tag ); ?></code></td>
						<td style="width:80px">
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'gpc_remove_meta_tag' ); ?>
								<input type="hidden" name="action" value="gpc_remove_meta_tag" />
								<input type="hidden" name="index" value="<?php echo esc_attr( $i ); ?>" />
								<?php submit_button( __( 'Remove', 'gpc' ), 'small delete', '', false ); ?>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:10px">
				<?php wp_nonce_field( 'gpc_add_meta_tag' ); ?>
				<input type="hidden" name="action" value="gpc_add_meta_tag" />
				<input type="text" name="meta_content" class="regular-text" placeholder="<?php esc_attr_e( 'verification code from Google', 'gpc' ); ?>" required />
				<?php submit_button( __( 'Add', 'gpc' ), 'secondary', '', false ); ?>
			</form>

			<h3><?php esc_html_e( 'Option B: HTML file upload', 'gpc' ); ?></h3>
			<p><?php esc_html_e( 'Google gives you a file like google1234567890abcdef.html with one line of HTML inside. Enter the filename and paste that exact content; this plugin will serve it at that URL on this site without needing FTP/root access.', 'gpc' ); ?></p>
			<table class="widefat" style="max-width:700px">
				<tbody>
				<?php foreach ( $html_files as $filename => $body ) : ?>
					<tr>
						<td><code><?php echo esc_html( $filename ); ?></code></td>
						<td><code><?php echo esc_html( $body ); ?></code></td>
						<td style="width:80px">
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'gpc_remove_html_file' ); ?>
								<input type="hidden" name="action" value="gpc_remove_html_file" />
								<input type="hidden" name="filename" value="<?php echo esc_attr( $filename ); ?>" />
								<?php submit_button( __( 'Remove', 'gpc' ), 'small delete', '', false ); ?>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:10px">
				<?php wp_nonce_field( 'gpc_add_html_file' ); ?>
				<input type="hidden" name="action" value="gpc_add_html_file" />
				<p>
					<input type="text" name="filename" class="regular-text" placeholder="google1234567890abcdef.html" required />
				</p>
				<p>
					<textarea name="file_body" class="large-text" rows="2" placeholder="google-site-verification: google1234567890abcdef.html" required></textarea>
				</p>
				<?php submit_button( __( 'Add', 'gpc' ), 'secondary', '', false ); ?>
			</form>

			<hr />

			<h2><?php esc_html_e( '3. Google News sitemap', 'gpc' ); ?></h2>
			<p>
				<?php esc_html_e( 'Submit this URL in Publisher Center / Search Console as your news sitemap. It only ever lists posts published on this site in the last 48 hours, scoped to this path — it will never include articles from other Greenpeace country sites.', 'gpc' ); ?>
			</p>
			<p><code><a href="<?php echo esc_url( $sitemap_url ); ?>" target="_blank"><?php echo esc_html( $sitemap_url ); ?></a></code></p>
			<p class="description"><?php esc_html_e( 'If this 404s, go to Settings > Permalinks and click Save once to flush rewrite rules.', 'gpc' ); ?></p>

			<hr />

			<h2><?php esc_html_e( '4. Structured data', 'gpc' ); ?></h2>
			<p><?php esc_html_e( 'NewsArticle JSON-LD is automatically added to every post — no setup needed. You can verify it with Google\'s Rich Results Test on any post URL.', 'gpc' ); ?></p>
		</div>
		<?php
	}
}
