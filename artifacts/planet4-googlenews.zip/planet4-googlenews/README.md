# Greenpeace Publisher Center Connector

**Created by Elad Aybes.**

A WordPress plugin that solves Google Publisher Center / Google News verification and feed problems for a [Planet4](https://github.com/greenpeace/planet4) site that runs in a **subdirectory** of a domain it does not control the root of.

## The problem

Greenpeace's international domain is `www.greenpeace.org`. Local Greenpeace sites such as Greenpeace Israel run under a subdirectory of that domain, e.g.:

```
https://www.greenpeace.org/israel
```

Greenpeace Israel manages its own Planet4 WordPress install, but has **no access to the root** of `www.greenpeace.org` — no DNS access, no FTP/file access to the domain root, nothing above `/israel`.

This breaks the standard way of verifying a site in Google Search Console / Google Publisher Center, because most guides assume you can either:

- Verify a **Domain property**, which requires adding a DNS TXT record at the root of the domain, or
- Upload an HTML verification file to the **web root** (`https://www.greenpeace.org/google1234.html`)

Both require access the local site owner doesn't have. As a result, the local Greenpeace site can't get verified, and its articles never make it into Google News or Discovery recommendations.

## The fix

Google Search Console and Publisher Center actually support a second property type that doesn't require root access at all: **"URL prefix"** verification. A URL-prefix property only needs to prove ownership of the *specific path* it's registered for (`https://www.greenpeace.org/israel/`), and that proof can be satisfied entirely from within WordPress, because WordPress fully controls everything served under that path.

This plugin implements everything needed to make URL-prefix verification — and subsequent Google News / Discovery indexing — work end to end, without ever touching the domain root:

1. **Site verification** (two methods, both root-free)
2. **A Google News sitemap scoped only to this site**
3. **NewsArticle structured data (JSON-LD) on every post**

## Features

### 1. Site verification

#### Option A — HTML tag method
Paste the `content="..."` value Google gives you when you choose the "HTML tag" verification method. The plugin injects:

```html
<meta name="google-site-verification" content="YOUR_CODE" />
```

into the `<head>` of every page on the site. You can add multiple tags at once (e.g. one for Search Console, one for Publisher Center, one for Google Analytics) — they don't conflict.

#### Option B — HTML file method
Google sometimes asks you to upload a file like `google1234567890abcdef.html` containing a single line of HTML, served at the exact URL `https://www.greenpeace.org/israel/google1234567890abcdef.html`.

Since the site owner has no FTP/file access to place a real file there, the plugin lets you paste the filename and its required contents into the admin screen. WordPress then intercepts that exact request and serves the content directly — achieving the same result as uploading a file, with no filesystem access required.

### 2. Google News sitemap

Available at:

```
https://www.greenpeace.org/israel/news-sitemap.xml
```

This sitemap is generated dynamically and:

- Includes **only posts published on this site** — never content from other Greenpeace country sites, even though they share the same parent domain
- Includes only posts published in the **last 48 hours**, per the [Google News sitemap specification](https://support.google.com/news/publisher-center/answer/9606710)
- Outputs proper `<news:news>` markup with publication name, language, publication date, and title

Submit this exact URL as the news sitemap in Search Console / Publisher Center.

> If the sitemap URL returns a 404, go to **Settings → Permalinks** in wp-admin and click **Save Changes** once. This flushes WordPress's rewrite rules so the new `/news-sitemap.xml` route is registered.

### 3. NewsArticle structured data

Every single post automatically gets `schema.org` `NewsArticle` JSON-LD injected into its `<head>`, with:

- `headline`
- `datePublished` / `dateModified`
- `author`
- `publisher` (name + logo, taken from the site icon)
- `image` (post featured image, if set)

This requires no configuration and works immediately after activation. You can verify it on any post URL using [Google's Rich Results Test](https://search.google.com/test/rich-results).

## Installation

1. Copy the `greenpeace-publisher-center` folder into `wp-content/plugins/`.
2. Activate **Greenpeace Publisher Center Connector** from the Plugins screen in wp-admin.
3. Go to **Settings → Publisher Center** to configure it.
4. Go to **Settings → Permalinks** and click **Save Changes** once, so the `/news-sitemap.xml` rewrite rule is registered.

## Configuration

All settings live under **Settings → Publisher Center** in wp-admin:

| Section | What to do |
|---|---|
| Publication details | Set the publication name and language code (e.g. `he`) used in the news sitemap and structured data. |
| Site verification — HTML tag | Paste the verification code Google gives you for the "HTML tag" method, then click **Add**. |
| Site verification — HTML file | Enter the filename (e.g. `google1234567890abcdef.html`) and the exact content Google gives you, then click **Add**. |
| Google News sitemap | Shows the sitemap URL to submit to Search Console / Publisher Center. |
| Structured data | Informational only — works automatically, no setup needed. |

## Step-by-step: what to do after installing

Follow these steps in order once the plugin is active.

**1. Flush permalinks**

wp-admin → **Settings → Permalinks** → click **Save Changes** (no need to change anything). This registers the `/news-sitemap.xml` route.

**2. Configure publication details**

wp-admin → **Settings → Publisher Center** → set:
- Publication name (e.g. "Greenpeace Israel")
- Language code (e.g. `he`)

**3. Verify the news sitemap is live**

Open `https://www.greenpeace.org/israel/news-sitemap.xml` in a browser. You should see XML output (it may be an empty `<urlset>...</urlset>` if no posts were published in the last 48h — that's fine).

**4. Create the Search Console property correctly**

In [Google Search Console](https://search.google.com/search-console):
- Click **Add property**
- Choose **URL prefix** (not "Domain")
- Enter exactly `https://www.greenpeace.org/israel/`

**5. Verify ownership**

Pick either method Google offers:
- **HTML tag** → copy the `content="..."` value → paste it into Settings → Publisher Center → "HTML tag" section → **Add**
- **HTML file** → copy the filename and its exact content → paste both into the "HTML file" section → **Add**

Then go back to Search Console and click **Verify**.

**6. Submit to Publisher Center**

Once Search Console shows the property as verified, go to [Google Publisher Center](https://publishercenter.google.com), select/add the same `greenpeace.org/israel` site, and submit `https://www.greenpeace.org/israel/news-sitemap.xml` as your content feed.

**7. Spot-check structured data**

Run any single post URL through [Google's Rich Results Test](https://search.google.com/test/rich-results) and confirm it detects a `NewsArticle` — this happens automatically, no config needed.

Once verification shows "Verified" in Search Console, the technical blocker is resolved. News/Discovery inclusion after that point is Google's editorial review, which can take time.

## Why "Domain" verification doesn't work here

| Property type | What it requires | Available to a subdirectory site owner? |
|---|---|---|
| Domain property | DNS TXT record at the domain's root | ❌ No — requires DNS access to `greenpeace.org`, which the local team doesn't have |
| URL prefix property | Proof of control over the specific URL path only | ✅ Yes — fully satisfied by WordPress itself, which is what this plugin automates |

## File structure

```
greenpeace-publisher-center/
├── greenpeace-publisher-center.php   # Plugin bootstrap
├── includes/
│   ├── class-gpc-verification.php    # Meta tag + HTML file verification
│   ├── class-gpc-news-sitemap.php    # Scoped /news-sitemap.xml
│   ├── class-gpc-structured-data.php # NewsArticle JSON-LD
│   └── class-gpc-admin.php           # Settings → Publisher Center screen
└── README.md
```

## Requirements

- WordPress with pretty permalinks enabled (required for `/news-sitemap.xml` to work)
- `manage_options` capability to access the settings screen

## Author

This plugin was created by **Elad Aybes** for the Greenpeace Israel Planet4 site.
